"""
why do we need a database?

user spreadsheet - 1,000,000 rows of data
got access to your data -
update the same spreadsheet -

size: database can be store as many volumes as it can be
accuracy: data type age: 7823ab
security: we can r/rw permission
Redundancy - database will not allow to store duplicate data based on the primary key
DR -
overwriting -
how about having more than one person overwriting the same data at the same time ?

cinema tikcet booking system
ABC - 10,000 are

DBMS: managing collection of databases

Database:
    RDBMS - MySQL, Oracle, SQL server, Postgres ( will store the structured data in structured format )
        Rows, Columns
        StudentManagementSystem
            Student
                columns - set of attributes which have defined data type
                    name(char), age(int), reg.num(int)
                rows - values of attributes
                    sugumar, 30, 1182309
            Department
                -
    NoSQL DBMS: Mongo, AWS DynamoDB, Cassandra ( its support mainly semi-structured and unstructured data )
        Collection, Document
        StudentManagementSystem
            Student - no defined schema
                {"name":"sugumar","age":30,"regnum":1182309}
                {"name":"daniel","age":30,"regnum":1122309}

    OLTP -  Online Transaction Processing System
    OLAP -  Online Analytical Processing system
"""

"""
SQL Database:

Database: collection or a set of tables,
    Products, Orders

Tables: basic building block of a db. rows and columns
    entity (or) table
    
Rows & Columns:

Columns Types:
    Simple - single value (age:)
    Composite - A value composed of some other values (name: firstname,lastname)
        Any composite attribute will be decomposed in to separate simple attributes
        
        (Date: year, month, day)
        ( 2022-04-15: 2022,04,15)
    Multi-valued: Multiple values for a single column, For example, the color of the car may be, black and red

Primary Key:
    a primary key is a column of unique values for each row
    
    registration portal - email as a unique key
    (suguvenk@gmail,)
    
    Primary keys are very important, not only to uniquely identify the rows, but also
    to connect between the tables and form relationships
    
One to Many relationship:
    for example,
        a customer can place more than one order
        but an order is only placed by one and only one consumer
    
    customers table
        CustomerID - primary Key
        FirstName
        Email    
    orders table
        OrderId 
        Product
        Price
        Customer_ID ( FK )
    
    customerId,Firstname,Email
    1234,Dan,dan@test.com
    5324,test2,test@test2.com
    
    orderId,Product,Price,CustomerID
    1,camera,5000,1234
    2,book,1000,1234
    
    select count(orders.id) from orders
    join customer on orders.customerID = customer.ID
    where customer.firstname="dan"
    
    INNER JOIN (or) JOIN -  common of both the tables
    LEFT JOIN (or) LEFT OUTER JOIN - retrieve the data from left table
    RIGHT JOIN (or) RIGHT OUTER JOIN - retrieve the data form right table
    FULL JOIN (or) FULL OUTER JOIN- retrieve overall data
    
    INNER JOIN:  JOIN is same as INNER JOIN
        Student
        RollNO, Name, Address, Phone, Age
        1, Harsh, DELHI, xxxxxxxxx, 18
        2, PRATIK, BIHAR, xxxxxxxxx, 21
        3, DAN, CHENNAI, xxxxxxxxx, 33
        4, DEEP, CALIFORNIA, xxxxxxxxx, 12
        
        studentCourse
        course_id,rollno
        1, 1
        2, 1
        2, 3
        3, 1
        3, 4
        4, 10
        
        select student.name,course.course_id from student
        join studentCourse on student.rollno = studentCourse.rollno
        
        student.name, course.course_id
        Harsh,       1
        Harsh,       2
        Harsh,       3
        DAN           2
        Deep          3
    
LEFT JOIN
       select student.name,studentCourse.course_id from student
       left join studentCourse on student.rollno = studentCourse.rollno
       
       Student
        RollNO, Name, Address, Phone, Age
        1, Harsh, DELHI, xxxxxxxxx, 18
        2, PRATIK, BIHAR, xxxxxxxxx, 21
        3, DAN, CHENNAI, xxxxxxxxx, 33
        4, DEEP, CALIFORNIA, xxxxxxxxx, 12
        
        studentCourse
        course_id,rollno
        1, 1
        2, 1
        2, 3
        3, 1
        3, 4
        4, 10
        
       student.name, course.course_id
       Harsh,       1
        Harsh,       2
        Harsh,       3
        DAN           2
        Deep          3
        PRATIK       NULL


LEFT JOIN
       select student.name,studentCourse.course_id from student
       right join studentCourse on student.rollno = studentCourse.rollno
       
       Student
        RollNO, Name, Address, Phone, Age
        1, Harsh, DELHI, xxxxxxxxx, 18
        2, PRATIK, BIHAR, xxxxxxxxx, 21
        3, DAN, CHENNAI, xxxxxxxxx, 33
        4, DEEP, CALIFORNIA, xxxxxxxxx, 12
        
        studentCourse
        course_id,rollno
        1, 1
        2, 1
        2, 3
        3, 1
        3, 4
        4, 10
        
        (all_common_data + rest of the data from right table)
        
       student.name, course.course_id
            Harsh                1
            Harsh                2
            DAN                  2
            Harsh                3
            Deep                 3
            NULL                 4

FULL JOIN:
    select student.name,studentCourse.course_id from student
       right join studentCourse on student.rollno = studentCourse.rollno
       
       Student
        RollNO, Name, Address, Phone, Age
        1, Harsh, DELHI, xxxxxxxxx, 18
        2, PRATIK, BIHAR, xxxxxxxxx, 21
        3, DAN, CHENNAI, xxxxxxxxx, 33
        4, DEEP, CALIFORNIA, xxxxxxxxx, 12
        
        studentCourse
        course_id,rollno
        1, 1
        2, 1
        2, 3
        3, 1
        3, 4
        4, 10
        
        (all_common_data + rest of the data from both the table)
        
       student.name, course.course_id
            Harsh                1
            Harsh                2
            DAN                  2
            Harsh                3
            Deep                 3
            NULL                 4
            PRATIK               NULL
    
customer can have many orders
but an single order will have only one customer

student can have enroller in many course
a course can be attend by multiple studnets

Teacher can learn many student
student can have multiple teachers

Many to Many Relationship:
    Student->Teacher
    
    Student:
        studentID, FirstName
        1, sugumar
        2, Dan
        3, Deep
    
    Course
        TeacherID, FirstName
        1, Teacher1
        2, Teacher2
        3, Teacher3
        
    Student_Teacher
       ID TeacherID, StudentID
            1          1
            1          2
            1          3
            2          1
            2          2
            2          3 
        
"""
"""
schema for one-to-many and many-to-many

Author - Book
Pizza - toppings
Author - Publisher
Publisher - Book
Doctor - Hospital


Music - Album - composer
Music - Playlist

Schema for User, UserRole, UserGroup, UserPermission

Doctor can do multiple surgeries

DoBrainSurgery - Da
DoBoneSurgery - DoctorA,DoctorC, DoctorD
DoSkinSurgery - DoctorB


User1,USer,User3,USer4
SE,SSE,QA,BA
Admin,Tester,Developer,ScrumMaster

CanCreateProject
CanUpdateProject
CanDeleteProject
CanViewProject
canCreateUserstory
canupdateUserSTory
candeleteUserSstory
canViewUSerstory
canCreateFeatureBranch
canUpdateFeatureBranch
CanDeleteFeatureBranch
canViewFeatureBranch
canCreateTestCase
canupdateTestCase
canviewTestcase
candeleteTestcase
"""

"""
Mode View Controller

Model Template View
"""