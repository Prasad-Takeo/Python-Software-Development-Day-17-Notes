"""
Web Framework -

a software framework that is designed to support the development of web applications
including web services, web resources and web APIs.

Web page - Database, UI, Backend-business logic, hosting, caching, session handling

Server-Side Frameworks

Django
Ruby on Rails
Spring

Client-side Frameworks

ReactJs
VueJs
AngularJs

Architecture of Web Framework: ( MVC Pattern )

Model: It comprises of all the data, business logic layers, it's guidelines and functions. The Model, upon
getting user input data from the controller, tells the way an updated interface should be displayed directly
to the View.
Bike Rental System - total number of bikes

View: it's for the graphical representation of data, it's the application front-end. The view gets the user-input
and communicates the same to the controller for examination and then update and reconstucts itself according
to the Models instructions or the controller's incase of the modification requirement is minimum

Controller: It translates the input data into the scope of business logic, It's a midway between Model and View,
It's gets the user input from the view and after processing it, the controller notifies the Model (or View) the changes
required.

"""

"""
View -> controller -> Model -> view

bikerental.com/rentBikes - view
rentBikes - controller
    Model - total number of bikes, rented bike, for whom it's rented, return information; ( schema - stored in database )
"""

"""
Quiz - Application

Model:
    Topics
        Questions
            Answers
            Option
    User
        Score
        Duration
        Status
        Details ( username, password, email, ph, dob)
View:
    Home Page - list of topics
        Login Page - username,password
    MCQ Page- based on the selected Topic, it will show the Q&A ( Game )
    Exam Page - which will take user to the Quiz attend page
    Status Page - which will show the results of the Exam
    
    
Controller:
    LoginController - evaluvate the user credentials passed
    showHomePage - list of topics from the Models
    MCQQuizPage - it'll show the list of MCQ's for the selected topic
    ExamPage - it'll track the session of User activity in attending the quiz.
    showStatus - based on the useractivity, it'll evaluvate and show the result

"""

"""
TIGHTLY Coupled design - 
    server side - client side are integrated ( Django )
        /login/ -> loginController -> redirect to the autheticated page
        controller will directly return the data to the html template
        
Loosely coupled design:
    server side - will render json, xml (mvc - Flask )
        /login/ -> loginController -> jwt token ( if authenticated ) else 401
        /showavailableBikes/ -> displaytotalavailableBikes -> return the no. of bikes available
            {
             "total": 80
            }
            
            (or)
            
            <bikes>80</bikes>
        
        
    client side - will consume the server side API (mvc- react js)

"""


"""
Design a MVC for Music system
Model
View
Controller
"""

"""
Advantages of web framework

security
    SQL injection
        username, password - (test, ****)
        
        username: test;delete from music_users //escaping test&891deletefrom music_users
    
        when the above username is passed to the controller: it'll do the validation
        
    Man in the middle Attack - CORS
    
    google page <iframe facebook.com/>
    
    overcome by the framework

URL Mapping
    /home - home_page
    /login - loginPage
    /logout - logoutPage
    
Efficiency: faster development, it'll allow you to use the things in reusable manner.
Cost: code faster and free of cost
support: documentation of frameworks is available to the outside world

    
"""